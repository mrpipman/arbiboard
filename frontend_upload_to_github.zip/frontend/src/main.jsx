import React from 'react';
import ReactDOM from 'react-dom/client';

const App = () => <h1>✅ Arbiboard is live via Netlify</h1>;

ReactDOM.createRoot(document.getElementById('root')).render(<App />);